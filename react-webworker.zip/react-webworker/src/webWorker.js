const worker = (self) => {
    function factorial(num) {
        if (num == 1)
            return 1
        return num * factorial(num - 1)
    }

    self.addEventListener("message", (evt) => {
        const num = evt.data
        postMessage(factorial(num))
    })
}
export default worker