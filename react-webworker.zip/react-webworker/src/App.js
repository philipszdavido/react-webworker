import worker from "./webWorker"

import React, { Component } from 'react';
import './index.css';

class App extends Component {
    constructor() {
        super()
        this.state = {
            result: null
        }
    }

    calc = () => {
        const data = Number(window.input.value)
        if (typeof data !== "number") {
            this.setState({ result: "input must be a number" })
            return
        }
        this.webWorker.postMessage(data)
    }

    componentDidMount() {
        let code = worker.toString()
        code = code.substring(code.indexOf("{") + 1, code.lastIndexOf("}"))
        const bb = new Blob([code], { type: "application/javascript" });
        this.webWorker = new Worker(URL.createObjectURL(bb))

        this.webWorker.addEventListener("message", (evt) => {
            const data = evt.data
            this.setState({ result: data })
        })
    }

    render() {
        return ( 
            <div>
                <input id="input" />
                <button onClick = {this.calc}> Click </button>
                
                <h3> Result: { this.state.result } </h3>  
            </div>
        )
    }
}

export default App